export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'smartwatch' | 'earbuds' | 'juicer';
  images: string[];
  features: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface User {
  username: string;
  isAdmin: boolean;
}
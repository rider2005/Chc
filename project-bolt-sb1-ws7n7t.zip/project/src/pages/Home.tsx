import React from 'react';
import { motion } from 'framer-motion';
import { useStore } from '../store';
import { ProductCard } from '../components/ProductCard';
import { ProductSlider } from '../components/ProductSlider';
import { AnimatedFeatures } from '../components/AnimatedFeatures';

export const Home = () => {
  const products = useStore((state) => state.products);

  return (
    <div className="min-h-screen bg-gray-100 pt-20">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center my-12"
        >
          <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
            Welcome to GIZMODEN
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Discover the Future of Smart Living
          </p>
        </motion.div>

        <ProductSlider products={products} />
        
        <AnimatedFeatures />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="my-12"
        >
          <h2 className="text-3xl font-bold text-center mb-8">Our Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};
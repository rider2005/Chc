import React from 'react';
import { motion } from 'framer-motion';
import { useStore } from '../store';
import { Trash, Plus, Minus } from 'lucide-react';

export const Cart = () => {
  const { cart, removeFromCart, updateQuantity } = useStore();
  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleCheckout = () => {
    // Integrate with Stripe or other payment processor
    alert('Proceeding to checkout...');
  };

  return (
    <div className="min-h-screen bg-gray-100 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h1 className="text-2xl font-bold mb-6">Your Cart</h1>
          
          {cart.length === 0 ? (
            <p>Your cart is empty</p>
          ) : (
            <>
              <div className="space-y-4">
                {cart.map((item) => (
                  <motion.div
                    key={item.product.id}
                    layout
                    className="flex items-center justify-between border-b pb-4"
                  >
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-20 h-20 object-cover rounded"
                    />
                    
                    <div className="flex-1 mx-4">
                      <h3 className="font-semibold">{item.product.name}</h3>
                      <p className="text-gray-600">${item.product.price}</p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => updateQuantity(item.product.id, Math.max(0, item.quantity - 1))}
                        className="p-1 rounded-lg hover:bg-gray-100"
                      >
                        <Minus className="w-5 h-5" />
                      </motion.button>
                      <span>{item.quantity}</span>
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-1 rounded-lg hover:bg-gray-100"
                      >
                        <Plus className="w-5 h-5" />
                      </motion.button>
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => removeFromCart(item.product.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-6">
                <div className="text-xl font-bold">Total: ${total.toFixed(2)}</div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleCheckout}
                  className="w-full mt-4 bg-indigo-600 text-white py-3 rounded-lg"
                >
                  Proceed to Checkout
                </motion.button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
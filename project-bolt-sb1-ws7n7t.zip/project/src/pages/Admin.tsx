import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useStore } from '../store';
import { Product } from '../types';
import { Plus, Edit, Trash } from 'lucide-react';

export const Admin = () => {
  const { products, setProducts, user } = useStore();
  const [editing, setEditing] = useState<Product | null>(null);

  if (!user?.isAdmin) {
    return <div>Access denied</div>;
  }

  const handleSave = (product: Product) => {
    if (editing) {
      setProducts(products.map((p) => (p.id === product.id ? product : p)));
    } else {
      setProducts([...products, { ...product, id: Date.now().toString() }]);
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    setProducts(products.filter((p) => p.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-100 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setEditing({ id: '', name: '', description: '', price: 0, category: 'smartwatch', images: [], features: [] })}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
            >
              <Plus className="w-5 h-5" />
              <span>Add Product</span>
            </motion.button>
          </div>

          <div className="space-y-4">
            {products.map((product) => (
              <motion.div
                key={product.id}
                layout
                className="border rounded-lg p-4 flex justify-between items-center"
              >
                <div>
                  <h3 className="font-semibold">{product.name}</h3>
                  <p className="text-gray-600">${product.price}</p>
                </div>
                <div className="flex space-x-2">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setEditing(product)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                  >
                    <Edit className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleDelete(product.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                  >
                    <Trash className="w-5 h-5" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
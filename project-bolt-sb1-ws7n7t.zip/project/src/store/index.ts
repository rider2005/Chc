import { create } from 'zustand';
import { CartItem, Product, User } from '../types';

interface Store {
  products: Product[];
  cart: CartItem[];
  user: User | null;
  setProducts: (products: Product[]) => void;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

export const useStore = create<Store>((set) => ({
  products: [
    {
      id: '1',
      name: 'GizmoWatch Pro',
      description: 'Premium smartwatch with health tracking',
      price: 299.99,
      category: 'smartwatch',
      images: [
        'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800',
        'https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?w=800'
      ],
      features: ['Heart Rate Monitor', 'GPS', 'Sleep Tracking']
    },
    {
      id: '2',
      name: 'AirPods Ultra',
      description: 'Wireless earbuds with noise cancellation',
      price: 199.99,
      category: 'earbuds',
      images: [
        'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800',
        'https://images.unsplash.com/photo-1608156639585-b3a032ef9689?w=800'
      ],
      features: ['Active Noise Cancellation', 'Wireless Charging', '24h Battery']
    },
    {
      id: '3',
      name: 'PowerJuice X1',
      description: 'Smart juicer with preset programs',
      price: 149.99,
      category: 'juicer',
      images: [
        'https://images.unsplash.com/photo-1622679201178-1d28c88f1664?w=800',
        'https://images.unsplash.com/photo-1589010588553-46e8e7c21788?w=800'
      ],
      features: ['Digital Display', 'Multiple Programs', 'Easy Clean']
    }
  ],
  cart: [],
  user: null,
  setProducts: (products) => set({ products }),
  addToCart: (product) =>
    set((state) => {
      const existingItem = state.cart.find((item) => item.product.id === product.id);
      if (existingItem) {
        return {
          cart: state.cart.map((item) =>
            item.product.id === product.id
              ? { ...item, quantity: item.quantity + 1 }
              : item
          ),
        };
      }
      return { cart: [...state.cart, { product, quantity: 1 }] };
    }),
  removeFromCart: (productId) =>
    set((state) => ({
      cart: state.cart.filter((item) => item.product.id !== productId),
    })),
  updateQuantity: (productId, quantity) =>
    set((state) => ({
      cart: state.cart.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      ),
    })),
  login: (username, password) => {
    if (username === 'chc' && password === 'chc2005') {
      set({ user: { username, isAdmin: true } });
      return true;
    }
    return false;
  },
  logout: () => set({ user: null }),
}));